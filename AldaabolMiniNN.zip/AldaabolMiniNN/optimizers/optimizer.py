class Optimizer:
    def update(self, layer):
        raise NotImplementedError  